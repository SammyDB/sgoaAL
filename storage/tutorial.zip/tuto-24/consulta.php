<?php
require("conexion.php");
$prove = mysqli_real_escape_string($con, $_POST["idproovedor"]);
$query = 'SELECT * FROM inventario WHERE IdProveedor = "'.$prove.'"';
$result = mysqli_query($con, $query);
while($row = mysqli_fetch_array($result, MYSQL_ASSOC))
{
    echo '<option value="' .$row["IdPrducto"]. '">' .$row["Producto"]. '</option>';
}
mysqli_close($con);
?>
