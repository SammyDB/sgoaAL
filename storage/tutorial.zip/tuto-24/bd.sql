DROP TABLE IF EXISTS `inventario`;
CREATE TABLE IF NOT EXISTS `inventario` (
  `IdProducto` int(11) NOT NULL AUTO_INCREMENT,
  `Producto` varchar(100) DEFAULT NULL,
  `IdProveedor` varchar(100) DEFAULT NULL,
  `Cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`IdProducto`, `Producto`, `IdProveedor`, `Cantidad`) VALUES
(1, 'Jabón Dove Avena', '1', 2),
(2, 'Shampoo Head Shoulders', '1', 4),
(3, 'Detergente Ariel', '1', 10),
(4, 'Prestobarba Gillete', '1', 3),
(5, 'Cepillo de dientes ORAL-B', '1', 1),
(6, 'Shampoo Pantene PRO-V', '1', 7),
(7, 'Portatil Sony VAIO', '2', 22),
(8, 'Televisor FULL HD 32"', '2', 11),
(9, 'Smartphone XPERIA', '2', 9),
(10, 'Camara de video LCD', '2', 8),
(11, 'Samsung Galaxy TAB 7"', '3', 2),
(12, 'Televisor FULL HD 48" Samsung', '3', 4),
(13, 'Samsung Galaxy X5', '3', 23),
(14, 'Minicomponente de audio LG', '4', 11),
(15, 'Televisor FULL HD 54" LCD', '4', 3);

DROP TABLE IF EXISTS `proveedor`;
CREATE TABLE IF NOT EXISTS `proveedor` (
  `IdProveedor` int(11) DEFAULT NULL,
  `NombreProveedor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `proveedor` (`IdProveedor`, `NombreProveedor`) VALUES
(1, 'P&G'),
(2, 'Sony'),
(3, 'Samsung'),
(4, 'LG'),
(4, 'Panasonic');
